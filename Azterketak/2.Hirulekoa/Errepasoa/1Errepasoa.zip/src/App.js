import Eskaera from "./components/Eskaera";

function App() {
  return (
    <Eskaera />
  );
}

export default App;
